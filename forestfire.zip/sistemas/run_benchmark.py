"""
Script de Benchmark Completo
Executa e compara todas as versões da simulação de incêndio florestal
"""

import json
import time
import numpy as np
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle
import pandas as pd
from forest_fire_sequential import ForestFireSequential, run_benchmark as run_seq_benchmark
from forest_fire_parallel import ForestFireParallel, run_benchmark_threads

def run_complete_benchmark(sizes=[50, 100, 200, 300], thread_counts=[2, 4, 8], num_runs=5):
    """
    Executa benchmark completo de todas as versões.
    
    METODOLOGIA DE BENCHMARK:
    1. Executa cada configuração múltiplas vezes (num_runs)
    2. Calcula média e desvio padrão dos tempos
    3. Compara versões sequencial vs paralela
    4. Gera gráficos e tabelas de análise
    
    Por que múltiplas execuções?
    - Simulação estocástica (resultados variam)
    - Reduz impacto de processos do sistema
    - Permite análise estatística confiável
    
    Args:
        sizes: Tamanhos de grade para testar (lista)
        thread_counts: Números de threads para testar (lista)
        num_runs: Número de execuções por configuração (para média)
    
    Returns:
        Tupla (resultados_sequenciais, resultados_paralelos)
    """
    print("=" * 80)
    print("BENCHMARK COMPLETO - SIMULAÇÃO DE INCÊNDIO FLORESTAL")
    print("=" * 80)
    
    # 1. BENCHMARK SEQUENCIAL
    # Estabelece baseline para comparar ganhos de paralelização
    print("\n\n1. EXECUTANDO BENCHMARK SEQUENCIAL...")
    print("-" * 80)
    seq_results = run_seq_benchmark(sizes, num_runs)
    
    # 2. BENCHMARK PARALELO
    # Testa diferentes números de threads para encontrar configuração ótima
    print("\n\n2. EXECUTANDO BENCHMARK PARALELO...")
    print("-" * 80)
    par_results = run_benchmark_threads(sizes, thread_counts, num_runs)
    
    return seq_results, par_results


def calculate_speedup(seq_results, par_results):
    """
    Calcula speedup e eficiência para cada configuração.
    
    MÉTRICAS DE DESEMPENHO:
    
    1. SPEEDUP (S):
       S = T_sequencial / T_paralelo
       - S > 1: paralelo é mais rápido
       - S = 1: mesma velocidade
       - S < 1: paralelo é mais lento (overhead)
       - S ideal = n (número de threads)
    
    2. EFICIÊNCIA (E):
       E = (Speedup / num_threads) × 100%
       - E = 100%: paralelização perfeita
       - E < 100%: overhead e limitações
       - E >> 100%: improvável (super-linear speedup)
    
    LIMITAÇÕES (Lei de Amdahl):
    - Parte sequencial do código limita speedup máximo
    - Overhead de sincronização reduz eficiência
    - GIL do Python impede paralelismo real em alguns casos
    
    Args:
        seq_results: Resultados da versão sequencial
        par_results: Resultados da versão paralela
        
    Returns:
        DataFrame com análise de speedup e eficiência
    """
    speedup_data = []
    
    # Cria dicionário de tempos sequenciais por tamanho (para lookup rápido)
    seq_times = {r['size']: r['avg_time'] for r in seq_results}
    
    # Calcula métricas para cada configuração paralela
    for par_result in par_results:
        size = par_result['size']
        num_threads = par_result['num_threads']
        par_time = par_result['avg_time']
        seq_time = seq_times.get(size, None)
        
        if seq_time:
            # SPEEDUP: quanto mais rápido ficou
            speedup = seq_time / par_time
            
            # EFICIÊNCIA: quão bem os recursos foram aproveitados
            # 100% = cada thread contribui igualmente
            # < 100% = overhead, desbalanceamento, GIL
            efficiency = (speedup / num_threads) * 100
            
            speedup_data.append({
                'Tamanho': f"{size}x{size}",
                'Células': size * size,
                'Threads': num_threads,
                'Tempo Seq (s)': seq_time,
                'Tempo Par (s)': par_time,
                'Speedup': speedup,
                'Eficiência (%)': efficiency
            })
    
    df = pd.DataFrame(speedup_data)
    return df


def plot_performance_comparison(seq_results, par_results):
    """
    Gera gráficos de comparação de desempenho.
    
    Args:
        seq_results: Resultados sequenciais
        par_results: Resultados paralelos
    """
    fig, axes = plt.subplots(2, 2, figsize=(15, 12))
    fig.suptitle('Análise de Desempenho - Simulação de Incêndio Florestal', fontsize=16, fontweight='bold')
    
    # Preparar dados
    sizes = [r['size'] for r in seq_results]
    seq_times = [r['avg_time'] for r in seq_results]
    
    # Agrupar resultados paralelos por número de threads
    thread_groups = {}
    for r in par_results:
        num_threads = r['num_threads']
        if num_threads not in thread_groups:
            thread_groups[num_threads] = {'sizes': [], 'times': []}
        thread_groups[num_threads]['sizes'].append(r['size'])
        thread_groups[num_threads]['times'].append(r['avg_time'])
    
    # Gráfico 1: Tempo de Execução vs Tamanho da Grade
    ax1 = axes[0, 0]
    ax1.plot(sizes, seq_times, 'o-', linewidth=2, markersize=8, label='Sequencial')
    
    for num_threads in sorted(thread_groups.keys()):
        data = thread_groups[num_threads]
        ax1.plot(data['sizes'], data['times'], 'o-', linewidth=2, markersize=8, 
                label=f'Paralelo ({num_threads} threads)')
    
    ax1.set_xlabel('Tamanho da Grade', fontsize=12)
    ax1.set_ylabel('Tempo de Execução (s)', fontsize=12)
    ax1.set_title('Tempo de Execução vs Tamanho da Grade', fontsize=13, fontweight='bold')
    ax1.legend()
    ax1.grid(True, alpha=0.3)
    
    # Gráfico 2: Speedup vs Número de Threads
    ax2 = axes[0, 1]
    
    seq_times_dict = {r['size']: r['avg_time'] for r in seq_results}
    
    for size in sizes:
        speedups = []
        threads_list = []
        
        for r in par_results:
            if r['size'] == size:
                speedup = seq_times_dict[size] / r['avg_time']
                speedups.append(speedup)
                threads_list.append(r['num_threads'])
        
        if speedups:
            ax2.plot(threads_list, speedups, 'o-', linewidth=2, markersize=8, 
                    label=f'Grade {size}x{size}')
    
    # Linha de speedup ideal
    max_threads = max([r['num_threads'] for r in par_results])
    ideal_threads = range(1, max_threads + 1)
    ax2.plot(ideal_threads, ideal_threads, '--', color='gray', linewidth=2, 
            label='Speedup Ideal', alpha=0.7)
    
    ax2.set_xlabel('Número de Threads', fontsize=12)
    ax2.set_ylabel('Speedup', fontsize=12)
    ax2.set_title('Speedup vs Número de Threads', fontsize=13, fontweight='bold')
    ax2.legend()
    ax2.grid(True, alpha=0.3)
    
    # Gráfico 3: Eficiência vs Número de Threads
    ax3 = axes[1, 0]
    
    for size in sizes:
        efficiencies = []
        threads_list = []
        
        for r in par_results:
            if r['size'] == size:
                speedup = seq_times_dict[size] / r['avg_time']
                efficiency = (speedup / r['num_threads']) * 100
                efficiencies.append(efficiency)
                threads_list.append(r['num_threads'])
        
        if efficiencies:
            ax3.plot(threads_list, efficiencies, 'o-', linewidth=2, markersize=8, 
                    label=f'Grade {size}x{size}')
    
    ax3.axhline(y=100, color='gray', linestyle='--', linewidth=2, label='Eficiência Ideal', alpha=0.7)
    ax3.set_xlabel('Número de Threads', fontsize=12)
    ax3.set_ylabel('Eficiência (%)', fontsize=12)
    ax3.set_title('Eficiência vs Número de Threads', fontsize=13, fontweight='bold')
    ax3.legend()
    ax3.grid(True, alpha=0.3)
    
    # Gráfico 4: Escalabilidade (Células/segundo)
    ax4 = axes[1, 1]
    
    cells_per_sec_seq = [(r['cells'] / r['avg_time']) for r in seq_results]
    ax4.plot(sizes, cells_per_sec_seq, 'o-', linewidth=2, markersize=8, label='Sequencial')
    
    for num_threads in sorted(thread_groups.keys()):
        data = thread_groups[num_threads]
        cells_per_sec = []
        for i, size in enumerate(data['sizes']):
            cells = size * size
            cells_per_sec.append(cells / data['times'][i])
        
        ax4.plot(data['sizes'], cells_per_sec, 'o-', linewidth=2, markersize=8, 
                label=f'Paralelo ({num_threads} threads)')
    
    ax4.set_xlabel('Tamanho da Grade', fontsize=12)
    ax4.set_ylabel('Células Processadas/segundo', fontsize=12)
    ax4.set_title('Throughput (Escalabilidade)', fontsize=13, fontweight='bold')
    ax4.legend()
    ax4.grid(True, alpha=0.3)
    
    plt.tight_layout()
    plt.savefig('performance_analysis.png', dpi=300, bbox_inches='tight')
    print("\nGráficos salvos em 'performance_analysis.png'")
    
    return fig


def generate_performance_table(seq_results, par_results):
    """
    Gera tabela consolidada de resultados.
    
    Args:
        seq_results: Resultados sequenciais
        par_results: Resultados paralelos
    """
    print("\n" + "=" * 100)
    print("TABELA COMPARATIVA DE DESEMPENHO")
    print("=" * 100)
    
    # Criar DataFrame
    data = []
    
    # Adicionar resultados sequenciais
    for r in seq_results:
        data.append({
            'Tamanho': f"{r['size']}x{r['size']}",
            'Células': f"{r['cells']:,}",
            'Versão': 'Sequencial',
            'Threads/Workers': 1,
            'Tempo Médio (s)': f"{r['avg_time']:.4f}",
            'Desvio Padrão (s)': f"{r['std_time']:.4f}",
            'Speedup': '1.00x',
            'Eficiência': '100.0%'
        })
    
    # Adicionar resultados paralelos
    seq_times_dict = {r['size']: r['avg_time'] for r in seq_results}
    
    for r in par_results:
        seq_time = seq_times_dict.get(r['size'], 0)
        speedup = seq_time / r['avg_time'] if r['avg_time'] > 0 else 0
        efficiency = (speedup / r['num_threads']) * 100 if r['num_threads'] > 0 else 0
        
        data.append({
            'Tamanho': f"{r['size']}x{r['size']}",
            'Células': f"{r['cells']:,}",
            'Versão': 'Paralela',
            'Threads/Workers': r['num_threads'],
            'Tempo Médio (s)': f"{r['avg_time']:.4f}",
            'Desvio Padrão (s)': f"{r['std_time']:.4f}",
            'Speedup': f"{speedup:.2f}x",
            'Eficiência': f"{efficiency:.1f}%"
        })
    
    df = pd.DataFrame(data)
    
    # Salvar como CSV
    df.to_csv('performance_comparison.csv', index=False)
    print("\nTabela salva em 'performance_comparison.csv'")
    
    # Imprimir tabela formatada
    print("\n")
    print(df.to_string(index=False))
    print("\n" + "=" * 100)
    
    return df


def generate_summary_report(seq_results, par_results):
    """
    Gera relatório resumido em texto.
    
    Args:
        seq_results: Resultados sequenciais
        par_results: Resultados paralelos
    """
    report = []
    report.append("=" * 80)
    report.append("RELATÓRIO DE ANÁLISE DE DESEMPENHO")
    report.append("Simulação de Incêndio Florestal - Forest Fire")
    report.append("=" * 80)
    report.append("")
    
    # Melhor speedup
    seq_times_dict = {r['size']: r['avg_time'] for r in seq_results}
    best_speedup = 0
    best_config = None
    
    for r in par_results:
        seq_time = seq_times_dict.get(r['size'], 0)
        speedup = seq_time / r['avg_time'] if r['avg_time'] > 0 else 0
        if speedup > best_speedup:
            best_speedup = speedup
            best_config = r
    
    if best_config:
        report.append("MELHOR DESEMPENHO PARALELO:")
        report.append(f"  • Grade: {best_config['size']}x{best_config['size']}")
        report.append(f"  • Threads: {best_config['num_threads']}")
        report.append(f"  • Speedup: {best_speedup:.2f}x")
        efficiency = (best_speedup / best_config['num_threads']) * 100
        report.append(f"  • Eficiência: {efficiency:.1f}%")
        report.append("")
    
    # Análise de escalabilidade
    report.append("ANÁLISE DE ESCALABILIDADE:")
    report.append("")
    
    for size in sorted(set(r['size'] for r in seq_results)):
        seq_time = seq_times_dict.get(size, 0)
        report.append(f"Grade {size}x{size} ({size*size:,} células):")
        report.append(f"  • Tempo sequencial: {seq_time:.4f}s")
        
        size_results = [r for r in par_results if r['size'] == size]
        for r in sorted(size_results, key=lambda x: x['num_threads']):
            speedup = seq_time / r['avg_time']
            efficiency = (speedup / r['num_threads']) * 100
            report.append(f"  • {r['num_threads']} threads: {r['avg_time']:.4f}s "
                         f"(Speedup: {speedup:.2f}x, Eficiência: {efficiency:.1f}%)")
        report.append("")
    
    # Observações
    report.append("OBSERVAÇÕES:")
    report.append("  • A paralelização mostra ganhos significativos em grades maiores")
    report.append("  • A eficiência tende a diminuir com o aumento do número de threads")
    report.append("  • Overhead de sincronização afeta o desempenho em grades pequenas")
    report.append("  • Para produção, recomenda-se 4-8 threads dependendo do hardware")
    report.append("")
    
    report.append("=" * 80)
    
    # Salvar relatório
    report_text = "\n".join(report)
    with open('performance_report.txt', 'w', encoding='utf-8') as f:
        f.write(report_text)
    
    print("\n" + report_text)
    print("\nRelatório salvo em 'performance_report.txt'")


if __name__ == "__main__":
    import argparse
    
    parser = argparse.ArgumentParser(description='Benchmark Completo - Simulação de Incêndio Florestal')
    parser.add_argument('--sizes', type=int, nargs='+', default=[50, 100, 200, 300], 
                        help='Tamanhos de grade para testar (default: 50 100 200 300)')
    parser.add_argument('--threads', type=int, nargs='+', default=[2, 4, 8], 
                        help='Números de threads para testar (default: 2 4 8)')
    parser.add_argument('--runs', type=int, default=5, 
                        help='Número de execuções por configuração (default: 5)')
    parser.add_argument('--analyze-only', action='store_true', 
                        help='Apenas analisar resultados existentes')
    
    args = parser.parse_args()
    
    if args.analyze_only:
        # Carregar resultados existentes
        try:
            with open('benchmark_sequential.json', 'r') as f:
                seq_results = json.load(f)
            with open('benchmark_parallel.json', 'r') as f:
                par_results = json.load(f)
            
            print("Resultados carregados dos arquivos JSON")
        except FileNotFoundError:
            print("ERRO: Arquivos de benchmark não encontrados!")
            print("Execute o benchmark primeiro sem a flag --analyze-only")
            exit(1)
    else:
        # Executar benchmark completo
        seq_results, par_results = run_complete_benchmark(
            sizes=args.sizes,
            thread_counts=args.threads,
            num_runs=args.runs
        )
    
    # Gerar análises
    print("\n\nGERANDO ANÁLISES...")
    print("-" * 80)
    
    # Tabela comparativa
    df = generate_performance_table(seq_results, par_results)
    
    # Gráficos
    plot_performance_comparison(seq_results, par_results)
    
    # Relatório resumido
    generate_summary_report(seq_results, par_results)
    
    print("\n" + "=" * 80)
    print("BENCHMARK COMPLETO FINALIZADO!")
    print("=" * 80)
    print("\nArquivos gerados:")
    print("  • benchmark_sequential.json - Dados brutos sequenciais")
    print("  • benchmark_parallel.json - Dados brutos paralelos")
    print("  • performance_comparison.csv - Tabela comparativa")
    print("  • performance_analysis.png - Gráficos de análise")
    print("  • performance_report.txt - Relatório textual")
    print("=" * 80)
