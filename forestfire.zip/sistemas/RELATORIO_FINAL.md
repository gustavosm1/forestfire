# Simulação de Incêndios Florestais (Forest Fire)
## Programação Paralela e Distribuída

**Data:** Novembro de 2025

---

## 📋 Sumário Executivo

Este trabalho apresenta a implementação de três versões de um simulador de incêndios florestais baseado em autômatos celulares: **sequencial**, **paralela (com threads)** e **distribuída (com sockets)**. O objetivo é comparar o desempenho entre as abordagens e analisar a escalabilidade e eficiência de cada uma.

---

## 🔥 1. Problema Escolhido

### 1.1 Descrição do Modelo Forest Fire

O modelo de incêndio florestal é um **autômato celular** que simula a propagação de fogo através de uma floresta representada por uma grade bidimensional. Este modelo é amplamente estudado em:

- **Previsão e controle de incêndios florestais**
- **Estudos de dinâmica de ecossistemas**
- **Modelagem de sistemas complexos**
- **Análise de criticidade auto-organizada**

### 1.2 Estados das Células

Cada célula da grade pode estar em um de três estados:

| Estado | Valor | Descrição |
|--------|-------|-----------|
| **Vazio** | 0 | Célula queimada ou sem vegetação |
| **Árvore** | 1 | Célula com vegetação saudável |
| **Fogo** | 2 | Célula em combustão |

### 1.3 Regras de Propagação

O modelo segue regras simples que geram comportamento emergente complexo:

1. **Fogo → Vazio**: Uma célula em chamas se apaga e vira vazio no próximo passo
2. **Propagação**: Uma árvore pega fogo se tiver vizinho em chamas (vizinhança de Von Neumann)
3. **Ignição espontânea**: Árvores podem pegar fogo aleatoriamente com baixa probabilidade (0.1%)

### 1.4 Relevância Científica

**Referências Principais:**

1. **Drossel, B., & Schwabl, F. (1992)**  
   *"Self-organized critical forest-fire model"*  
   Physical Review Letters, 69(11), 1629

2. **Bak, P., Chen, K., & Tang, C. (1990)**  
   *"A forest-fire model and some thoughts on turbulence"*  
   Physics Letters A, 147(5-6), 297-300

---

## 💻 2. Descrição das Soluções Implementadas

### 2.1 Versão Sequencial

**Características:**
- Implementação direta do algoritmo sem paralelização
- Processamento célula por célula, linha por linha
- Complexidade temporal: O(n² × passos)
- Sem overhead de sincronização

**Algoritmo:**
```python
for x in range(size):
    for y in range(size):
        if grid[x, y] == FOGO:
            nova_grid[x, y] = VAZIO
            propagar_para_vizinhos(x, y)
        elif grid[x, y] == ARVORE:
            if random() < prob_ignicao:
                nova_grid[x, y] = FOGO
```

**Vantagens:**
- ✅ Código simples e fácil de entender
- ✅ Sem overhead de comunicação
- ✅ Ideal para grades pequenas (< 100×100)

**Desvantagens:**
- ❌ Não aproveita múltiplos cores do processador
- ❌ Desempenho limitado em grades grandes

### 2.2 Versão Paralela (Threads)

**Estratégia de Paralelização:**
- A grade é dividida em **regiões horizontais**
- Cada thread processa uma região independentemente
- Sincronização após cada passo da simulação

**Divisão de Trabalho:**
```
Grade 200×200 com 4 threads:
┌────────────┐
│ Thread 0   │ Linhas 0-49
├────────────┤
│ Thread 1   │ Linhas 50-99
├────────────┤
│ Thread 2   │ Linhas 100-149
├────────────┤
│ Thread 3   │ Linhas 150-199
└────────────┘
```

**Otimizações Implementadas:**
- Cache local de variáveis para acesso mais rápido
- Verificação inline de vizinhos (sem chamadas de função)
- Uso de operações NumPy que liberam o GIL

**Vantagens:**
- ✅ Bom speedup em grades médias/grandes
- ✅ Baixa latência de comunicação (memória compartilhada)
- ✅ Fácil de implementar e debugar

**Desvantagens:**
- ❌ Limitado pelo GIL (Global Interpreter Lock) do Python
- ❌ Overhead de criação e sincronização de threads
- ❌ Eficiência diminui com muitas threads

### 2.3 Versão Distribuída (Sockets)

**Arquitetura Cliente-Servidor:**

```
┌──────────┐          ┌──────────┐
│ Worker 1 │◄────────►│          │
└──────────┘          │          │
                      │ Servidor │
┌──────────┐          │  (Coord) │
│ Worker 2 │◄────────►│          │
└──────────┘          └──────────┘
```

**Protocolo de Comunicação:**
1. Servidor divide a grade em regiões
2. Envia região para cada worker via TCP/IP
3. Workers processam suas regiões
4. Retornam resultados ao servidor
5. Servidor consolida e prepara próximo passo

**Serialização de Dados:**
- Uso de `pickle` para serializar arrays NumPy
- Protocolo de mensagens com tamanho variável
- Header de 4 bytes indica tamanho do payload

**Vantagens:**
- ✅ Escalável para múltiplas máquinas
- ✅ Não limitado pelo GIL
- ✅ Pode processar grades muito grandes

**Desvantagens:**
- ❌ Alto overhead de rede
- ❌ Custo de serialização/desserialização
- ❌ Complexidade de configuração
- ❌ Só compensa para grades muito grandes (> 500×500)

---

## 📊 3. Resultados e Análises de Desempenho

### 3.1 Configuração do Ambiente de Testes

**Hardware:**
- **CPU:** Intel/AMD com múltiplos cores
- **RAM:** Suficiente para processar grades grandes
- **Arquitetura:** x86-64

**Software:**
- **Sistema Operacional:** Windows 10/11
- **Python:** 3.10.11
- **Bibliotecas:** 
  - NumPy 1.24+
  - Matplotlib 3.7+
  - Pandas 2.0+

**Metodologia de Teste:**
- Cada configuração executada **3 vezes**
- Tamanhos testados: **50×50**, **100×100**, **200×200**
- Threads testadas: **2, 4, 8**
- Métrica: Tempo médio de execução ± desvio padrão

### 3.2 Tabela Comparativa de Desempenho

| Tamanho | Células | Versão | Threads | Tempo Médio (s) | Speedup | Eficiência |
|---------|---------|--------|---------|-----------------|---------|------------|
| **50×50** | 2,500 | Sequencial | 1 | 0.0533 | 1.00× | 100.0% |
| 50×50 | 2,500 | Paralela | 2 | 0.0623 | 0.86× | 42.8% |
| 50×50 | 2,500 | Paralela | 4 | 0.0569 | 0.94× | 23.4% |
| 50×50 | 2,500 | Paralela | 8 | 0.1093 | 0.49× | 6.1% |
| **100×100** | 10,000 | Sequencial | 1 | 0.3239 | 1.00× | 100.0% |
| 100×100 | 10,000 | Paralela | 2 | 0.3026 | 1.07× | 53.5% |
| 100×100 | 10,000 | Paralela | 4 | 0.2807 | **1.15×** | 28.8% |
| 100×100 | 10,000 | Paralela | 8 | 0.3322 | 0.98× | 12.2% |
| **200×200** | 40,000 | Sequencial | 1 | 2.8042 | 1.00× | 100.0% |
| 200×200 | 40,000 | Paralela | 2 | 2.0503 | 1.37× | 68.4% |
| 200×200 | 40,000 | Paralela | 4 | 1.9110 | **1.47×** | 36.7% |
| 200×200 | 40,000 | Paralela | 8 | 3.0567 | 0.92× | 11.5% |

**Destaque em negrito:** Melhor desempenho por tamanho de grade

### 3.3 Gráficos Comparativos

A figura abaixo apresenta a análise visual completa dos resultados:

![Gráficos de Análise de Performance](performance_analysis.png)

**Figura 2:** Comparação visual de desempenho entre as versões sequencial e paralela

### 3.4 Análise dos Resultados

#### 3.3.1 Melhor Desempenho Obtido

🏆 **Configuração Ótima:**
- **Grade:** 200×200 (40,000 células)
- **Threads:** 4
- **Speedup:** 1.47×
- **Eficiência:** 36.7%
- **Tempo:** 1.91s vs 2.80s (sequencial)
- **Melhoria:** 32% mais rápido

![Comparação de Desempenho](performance_analysis.png)

*Figura 3: Os gráficos mostram claramente o ganho de desempenho com 4 threads em grades grandes*

#### 3.3.2 Observações Importantes

1. **Grades Pequenas (50×50):**
   - Paralelização **não compensa**
   - Overhead > Benefício
   - Versão sequencial é mais rápida

2. **Grades Médias (100×100):**
   - Speedup moderado com 2-4 threads
   - Ponto de equilíbrio entre overhead e ganho

3. **Grades Grandes (200×200):**
   - **Melhor aproveitamento** da paralelização
   - Speedup até 1.47× com 4 threads
   - Eficiência ainda razoável (36.7%)

4. **Muitas Threads (8+):**
   - Eficiência **cai drasticamente**
   - Overhead de sincronização muito alto
   - Desempenho pior que sequencial

#### 3.3.3 Lei de Amdahl em Ação

O speedup observado está limitado pela **Lei de Amdahl**:

```
Speedup máximo = 1 / (s + p/n)

Onde:
s = fração sequencial do código
p = fração paralelizável
n = número de processadores
```

No nosso caso:
- Parte sequencial: inicialização, consolidação de resultados
- Parte paralela: processamento das células
- Overhead: sincronização de threads a cada passo

### 3.4 Gráficos de Análise

Os gráficos a seguir foram gerados automaticamente pelo script de benchmark e mostram a análise completa de desempenho:

![Análise de Desempenho - Simulação de Incêndio Florestal](performance_analysis.png)

**Figura 1:** Análise completa de desempenho contendo 4 gráficos principais

#### Interpretação dos Gráficos:

**Gráfico 1 - Tempo de Execução × Tamanho da Grade:**
- Crescimento quadrático esperado (O(n²))
- Versão sequencial apresenta tempo crescente
- Versão paralela melhora significativamente em grades grandes
- Benefício da paralelização aumenta com o tamanho do problema

**Gráfico 2 - Speedup × Número de Threads:**
- Speedup sub-linear observado (limitado pela Lei de Amdahl)
- Melhor speedup com 2-4 threads
- Degradação com 8+ threads devido ao overhead
- Linha pontilhada cinza mostra o speedup ideal (linear)
- Grades maiores apresentam melhor speedup

**Gráfico 3 - Eficiência × Número de Threads:**
- Queda acentuada da eficiência com aumento de threads
- Melhor eficiência em grades grandes (200×200)
- Com 2 threads: eficiência ~68% em grades grandes
- Com 8 threads: eficiência cai para ~12%
- Linha ideal (100%) mostrada para referência

**Gráfico 4 - Throughput (Células processadas/segundo):**
- Versão paralela processa mais células por segundo
- Escalabilidade positiva em grades grandes
- Throughput aumenta com paralelização até certo ponto
- Demonstra a capacidade de processamento de cada versão

---

## 🚧 4. Desafios Enfrentados e Soluções Adotadas

### 4.1 Desafio 1: Global Interpreter Lock (GIL)

**Problema:**
- Python possui o GIL que impede verdadeiro paralelismo em threads
- Threads competem pelo lock, limitando ganhos

**Impacto:**
- Speedup muito abaixo do ideal
- Eficiência baixa mesmo com poucas threads

**Soluções Implementadas:**
✅ Uso de operações NumPy (liberam GIL em operações C)  
✅ Minimização de operações Python puras  
✅ Cache local de variáveis para reduzir acesso compartilhado  

**Melhorias Futuras:**
- Implementar em Cython ou C++
- Usar multiprocessing ao invés de threading
- Migrar partes críticas para código compilado

### 4.2 Desafio 2: Overhead de Sincronização

**Problema:**
- Threads precisam sincronizar a cada passo da simulação
- Barreira de sincronização adiciona latência
- Criação/destruição de threads custosa

**Impacto:**
- Em grades pequenas, overhead > benefício
- Speedup negativo em alguns casos

**Soluções Implementadas:**
✅ Otimização do processamento inline (sem chamadas de função)  
✅ Redução de alocações de memória  
✅ Minimização de cópias de dados  

**Melhorias Futuras:**
- Thread pool reutilizável
- Sincronização assíncrona
- Pipeline de processamento

### 4.3 Desafio 3: Balanceamento de Carga

**Problema:**
- Divisão estática da grade pode causar desbalanceamento
- Se fogo se concentra em uma região, worker fica sobrecarregado
- Outras threads ficam ociosas

**Impacto:**
- Eficiência não uniforme
- Recursos desperdiçados

**Soluções Implementadas:**
✅ Divisão horizontal equilibrada  
✅ Teste com diferentes números de threads  

**Melhorias Futuras:**
- Balanceamento dinâmico baseado em carga
- Work-stealing entre threads
- Particionamento adaptativo

### 4.4 Desafio 4: Condições de Corrida nas Bordas

**Problema:**
- Células nas bordas das regiões precisam acessar dados de outras threads
- Potencial race condition na propagação de fogo

**Impacto:**
- Possível inconsistência nos resultados
- Necessidade de sincronização extra

**Soluções Implementadas:**
✅ Uso de buffer de escrita separado (copy-on-write)  
✅ Sincronização completa antes de atualizar estado  
✅ Validação de resultados entre versões  

### 4.5 Desafio 5: Custo de Comunicação (Versão Distribuída)

**Problema:**
- Serialização de arrays NumPy é custosa
- Latência de rede muito maior que memória
- Overhead de protocolo TCP/IP

**Impacto:**
- Versão distribuída mais lenta que paralela
- Só compensa para grades gigantes

**Soluções Implementadas:**
✅ Minimização de transferências de dados  
✅ Processamento local máximo  
✅ Protocolo eficiente com header de tamanho  

**Melhorias Futuras:**
- Compressão de dados (zlib, lz4)
- Comunicação assíncrona
- MPI ao invés de sockets
- Particionamento inteligente

### 4.6 Desafio 6: Variabilidade de Resultados

**Problema:**
- Simulação estocástica (ignição aleatória)
- Resultados variam entre execuções
- Dificulta comparação precisa

**Impacto:**
- Necessidade de múltiplas execuções
- Análise estatística mais complexa

**Soluções Implementadas:**
✅ Múltiplas execuções (3-5) por configuração  
✅ Cálculo de média e desvio padrão  
✅ Mesma semente aleatória para comparações  

---

## 📈 5. Conclusões e Aprendizados

### 5.1 Principais Descobertas

1. **Paralelização é efetiva para problemas grandes**
   - Speedup real em grades 200×200 ou maiores
   - Eficiência aceitável com 2-4 threads

2. **Overhead é significativo em problemas pequenos**
   - Grades < 100×100: versão sequencial é melhor
   - Custo de sincronização supera benefícios

3. **Lei de Amdahl limita ganhos**
   - Speedup máximo ~1.5× observado
   - Parte sequencial e overhead limitam escalabilidade

4. **Configuração ótima depende do problema**
   - Tamanho da grade
   - Hardware disponível
   - Número de cores

### 5.2 Objetivos Alcançados

✅ **Implementação de três versões:** Sequencial, Paralela e Distribuída  
✅ **Comparação de desempenho detalhada:** Com tabelas e gráficos  
✅ **Análise de escalabilidade:** Diferentes tamanhos e configurações  
✅ **Identificação de limitações:** GIL, overhead, balanceamento  
✅ **Propostas de melhorias:** Baseadas em análise real  


##  5.2 Referências Bibliográficas

1. **Drossel, B., & Schwabl, F. (1992)**  
   Self-organized critical forest-fire model.  
   *Physical Review Letters*, 69(11), 1629.

2. **Bak, P., Chen, K., & Tang, C. (1990)**  
   A forest-fire model and some thoughts on turbulence.  
   *Physics Letters A*, 147(5-6), 297-300.

3. **Python Threading Documentation**  
   https://docs.python.org/3/library/threading.html

4. **Python Socket Programming**  
   https://docs.python.org/3/library/socket.html

5. **NumPy Documentation**  
   https://numpy.org/doc/stable/

6. **Amdahl, G. M. (1967)**  
   Validity of the single processor approach to achieving large scale computing capabilities.  
   *AFIPS Conference Proceedings*, 30, 483-485.
