"""
Simulação Distribuída de Incêndio Florestal usando Sockets
Baseado no modelo de autômato celular para propagação de fogo

Servidor coordena múltiplos workers que processam regiões da grade.

Referências:
- Drossel, B., & Schwabl, F. (1992). "Self-organized critical forest-fire model"
- Physical Review Letters, 69(11), 1629.
"""

import numpy as np
import time
from typing import Tuple
import socket
import pickle
import json
import threading

class ForestFireDistributedServer:
    """
    Servidor que coordena a simulação distribuída.
    
    ARQUITETURA CLIENTE-SERVIDOR:
    - Servidor: Mantém estado global da grade, coordena workers
    - Workers: Processam regiões da grade e retornam resultados
    - Comunicação: TCP/IP via sockets Python
    
    FLUXO DE EXECUÇÃO:
    1. Servidor aguarda conexões de workers
    2. A cada passo: divide grade e envia para workers
    3. Workers processam suas regiões
    4. Servidor recebe resultados e consolida
    5. Repete até não haver mais fogo
    
    VANTAGENS:
    - Escalabilidade para múltiplas máquinas
    - Sem limitação do GIL (cada worker é processo separado)
    
    DESVANTAGENS:
    - Overhead de rede alto
    - Serialização/desserialização custosa
    - Complexidade de configuração
    """
    
    def __init__(self, size: int, num_workers: int = 2, tree_prob: float = 0.6, 
                 fire_prob: float = 0.001, port: int = 5000):
        """
        Inicializa o servidor distribuído.
        
        Args:
            size: Tamanho da grade (size x size)
            num_workers: Número de workers esperados para conectar
            tree_prob: Probabilidade inicial de uma célula ter árvore
            fire_prob: Probabilidade de ignição espontânea
            port: Porta TCP para aceitar conexões de workers
        """
        self.size = size
        self.num_workers = num_workers
        self.tree_prob = tree_prob
        self.fire_prob = fire_prob
        self.port = port
        # Grade global mantida pelo servidor
        self.grid = np.zeros((size, size), dtype=np.int8)
        # Lista de sockets conectados aos workers
        self.worker_sockets = []
        # Endereços dos workers (para log/debug)
        self.worker_addresses = []
        self.initialize_forest()
        
    def initialize_forest(self):
        """Inicializa a floresta com árvores aleatórias."""
        self.grid = (np.random.random((self.size, self.size)) < self.tree_prob).astype(np.int8)
        
        # Inicia alguns focos de incêndio
        num_fires = max(1, self.size // 50)
        for _ in range(num_fires):
            x = np.random.randint(0, self.size)
            y = np.random.randint(0, self.size)
            self.grid[x, y] = 2
    
    def start_server(self):
        """
        Inicia o servidor e aguarda conexões dos workers.
        
        PROCESSO:
        1. Cria socket TCP/IP na porta especificada
        2. Coloca em modo listen (aguarda conexões)
        3. Aceita num_workers conexões
        4. Armazena sockets para comunicação futura
        
        PROTOCOLO TCP:
        - Confiável: garante entrega de pacotes
        - Orientado a conexão: handshake antes de transmitir
        - Ordenado: pacotes chegam na ordem enviada
        """
        # Cria socket TCP/IP
        server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        # Permite reutilizar porta imediatamente (evita "Address already in use")
        server_socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        # Bind: associa socket à porta específica
        # '0.0.0.0' aceita conexões de qualquer interface de rede
        server_socket.bind(('0.0.0.0', self.port))
        # Listen: coloca socket em modo de escuta
        # Parâmetro = tamanho da fila de conexões pendentes
        server_socket.listen(self.num_workers)
        
        print(f"Servidor iniciado na porta {self.port}")
        print(f"Aguardando {self.num_workers} workers...")
        
        # Aceita conexões de workers (BLOQUEIA até todos conectarem)
        for i in range(self.num_workers):
            # accept() bloqueia até um cliente conectar
            client_socket, address = server_socket.accept()
            self.worker_sockets.append(client_socket)
            self.worker_addresses.append(address)
            print(f"Worker {i+1} conectado: {address}")
        
        print("Todos os workers conectados!")
        return server_socket
    
    def distribute_regions(self):
        """
        Distribui regiões da grade para cada worker via rede.
        
        ESTRATÉGIA DE DIVISÃO:
        - Horizontal: cada worker recebe bloco de linhas contíguas
        - Overlap: inclui linha extra nas bordas para tratar vizinhança
        
        PROTOCOLO DE COMUNICAÇÃO:
        1. Serializa dados com pickle (converte objetos Python para bytes)
        2. Envia tamanho da mensagem (4 bytes, big-endian)
        3. Envia dados serializados
        
        Por que pickle?
        - Serializa arrays NumPy eficientemente
        - Preserva tipos de dados Python
        - Simples de usar
        
        Alternativas:
        - JSON: mais lento, não suporta NumPy nativamente
        - Protocol Buffers: mais rápido, mas mais complexo
        - MessagePack: bom compromisso
        """
        # Calcula quantas linhas cada worker processa
        rows_per_worker = self.size // self.num_workers
        
        # Envia região para cada worker
        for i, worker_socket in enumerate(self.worker_sockets):
            # Calcula limites da região deste worker
            start_row = i * rows_per_worker
            if i == self.num_workers - 1:
                end_row = self.size  # Último worker pega linhas restantes
            else:
                end_row = (i + 1) * rows_per_worker
            
            # OVERLAP: inclui linha extra de cada lado para tratar bordas
            # Necessário porque células nas bordas precisam acessar vizinhos
            # de outras regiões para propagar fogo corretamente
            extended_start = max(0, start_row - 1)
            extended_end = min(self.size, end_row + 1)
            
            # Prepara dados para enviar ao worker
            region_data = {
                'start_row': start_row,  # Linha inicial de responsabilidade
                'end_row': end_row,  # Linha final de responsabilidade
                'extended_start': extended_start,  # Início com overlap
                'extended_end': extended_end,  # Fim com overlap
                'grid_region': self.grid[extended_start:extended_end].copy(),
                'fire_prob': self.fire_prob,
                'size': self.size
            }
            
            # SERIALIZAÇÃO: Converte dict Python para bytes
            data = pickle.dumps(region_data)
            
            # PROTOCOLO: Envia tamanho da mensagem primeiro (4 bytes)
            # Isso permite ao receptor saber quanto ler
            worker_socket.sendall(len(data).to_bytes(4, 'big'))
            # Envia dados serializados
            worker_socket.sendall(data)
    
    def collect_results(self) -> bool:
        """
        Coleta resultados processados dos workers.
        
        Returns:
            True se algum worker detectou fogo
        """
        has_fire = False
        
        for i, worker_socket in enumerate(self.worker_sockets):
            # Recebe tamanho da mensagem
            size_bytes = worker_socket.recv(4)
            if not size_bytes:
                continue
            
            msg_size = int.from_bytes(size_bytes, 'big')
            
            # Recebe dados
            data = b''
            while len(data) < msg_size:
                packet = worker_socket.recv(min(msg_size - len(data), 4096))
                if not packet:
                    break
                data += packet
            
            result = pickle.loads(data)
            
            # Atualiza grade com resultado do worker
            start_row = result['start_row']
            end_row = result['end_row']
            self.grid[start_row:end_row] = result['processed_region']
            
            if result['has_fire']:
                has_fire = True
        
        return has_fire
    
    def simulate(self, max_steps: int = 1000) -> Tuple[int, float, dict]:
        """
        Executa a simulação distribuída completa.
        
        Args:
            max_steps: Número máximo de iterações
            
        Returns:
            Tupla com (número de passos, tempo de execução, estatísticas)
        """
        server_socket = self.start_server()
        
        start_time = time.time()
        steps = 0
        
        initial_trees = np.sum(self.grid == 1)
        
        try:
            while steps < max_steps:
                # Distribui estado atual
                self.distribute_regions()
                
                # Coleta resultados processados
                has_fire = self.collect_results()
                
                steps += 1
                
                if not has_fire:
                    break
                
        finally:
            # Envia sinal de término para workers
            for worker_socket in self.worker_sockets:
                try:
                    stop_data = pickle.dumps({'stop': True})
                    worker_socket.sendall(len(stop_data).to_bytes(4, 'big'))
                    worker_socket.sendall(stop_data)
                    worker_socket.close()
                except:
                    pass
            
            server_socket.close()
        
        end_time = time.time()
        execution_time = end_time - start_time
        
        final_trees = np.sum(self.grid == 1)
        burned_trees = initial_trees - final_trees
        burn_percentage = (burned_trees / initial_trees * 100) if initial_trees > 0 else 0
        
        stats = {
            'initial_trees': int(initial_trees),
            'final_trees': int(final_trees),
            'burned_trees': int(burned_trees),
            'burn_percentage': float(burn_percentage),
            'steps': steps,
            'num_workers': self.num_workers
        }
        
        return steps, execution_time, stats


class ForestFireDistributedWorker:
    """Worker que processa uma região da grade."""
    
    def __init__(self, server_host: str = 'localhost', server_port: int = 5000):
        """
        Inicializa o worker.
        
        Args:
            server_host: Endereço do servidor
            server_port: Porta do servidor
        """
        self.server_host = server_host
        self.server_port = server_port
        self.socket = None
    
    def get_neighbors(self, x: int, y: int, size: int) -> list:
        """Retorna os vizinhos válidos de uma célula (Von Neumann)."""
        neighbors = []
        for dx, dy in [(-1, 0), (1, 0), (0, -1), (0, 1)]:
            nx, ny = x + dx, y + dy
            if 0 <= nx < size and 0 <= ny < size:
                neighbors.append((nx, ny))
        return neighbors
    
    def process_region(self, region_data: dict) -> dict:
        """
        Processa uma região da grade.
        
        Args:
            region_data: Dados da região a processar
            
        Returns:
            Dicionário com região processada e flag de fogo
        """
        start_row = region_data['start_row']
        end_row = region_data['end_row']
        extended_start = region_data['extended_start']
        extended_end = region_data['extended_end']
        grid_region = region_data['grid_region']
        fire_prob = region_data['fire_prob']
        size = region_data['size']
        
        new_region = grid_region.copy()
        has_fire = False
        
        # Offset para indexação correta
        offset = start_row - extended_start
        region_height = end_row - start_row
        
        for i in range(region_height):
            actual_row = i + offset
            for y in range(size):
                if grid_region[actual_row, y] == 2:  # Fogo
                    new_region[actual_row, y] = 0  # Vira vazio
                    has_fire = True
                    
                    # Propaga fogo para vizinhos
                    for dx, dy in [(-1, 0), (1, 0), (0, -1), (0, 1)]:
                        nx, ny = actual_row + dx, y + dy
                        if 0 <= nx < len(grid_region) and 0 <= ny < size:
                            if grid_region[nx, ny] == 1:  # Árvore
                                new_region[nx, ny] = 2  # Pega fogo
                                
                elif grid_region[actual_row, y] == 1:  # Árvore
                    # Ignição espontânea
                    if np.random.random() < fire_prob:
                        new_region[actual_row, y] = 2
                        has_fire = True
        
        # Retorna apenas a região que este worker é responsável
        processed_region = new_region[offset:offset+region_height]
        
        return {
            'start_row': start_row,
            'end_row': end_row,
            'processed_region': processed_region,
            'has_fire': has_fire
        }
    
    def connect_and_work(self):
        """Conecta ao servidor e processa trabalho."""
        self.socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.socket.connect((self.server_host, self.server_port))
        
        print(f"Conectado ao servidor {self.server_host}:{self.server_port}")
        
        try:
            while True:
                # Recebe tamanho da mensagem
                size_bytes = self.socket.recv(4)
                if not size_bytes:
                    break
                
                msg_size = int.from_bytes(size_bytes, 'big')
                
                # Recebe dados
                data = b''
                while len(data) < msg_size:
                    packet = self.socket.recv(min(msg_size - len(data), 4096))
                    if not packet:
                        break
                    data += packet
                
                region_data = pickle.loads(data)
                
                # Verifica se é sinal de parada
                if 'stop' in region_data:
                    print("Recebido sinal de parada")
                    break
                
                # Processa região
                result = self.process_region(region_data)
                
                # Envia resultado
                result_data = pickle.dumps(result)
                self.socket.sendall(len(result_data).to_bytes(4, 'big'))
                self.socket.sendall(result_data)
                
        finally:
            self.socket.close()
            print("Desconectado do servidor")


def run_benchmark_distributed(sizes: list, worker_counts: list, num_runs: int = 3):
    """
    Executa benchmark para diferentes configurações distribuídas.
    
    Args:
        sizes: Lista de tamanhos de grade
        worker_counts: Lista de números de workers
        num_runs: Número de execuções por configuração
    """
    results = []
    
    print("=" * 60)
    print("BENCHMARK - VERSÃO DISTRIBUÍDA (SOCKETS)")
    print("=" * 60)
    print("\nNOTA: Execute os workers manualmente antes de iniciar o servidor!")
    print("Comando: python forest_fire_distributed.py --worker --host <servidor>")
    print("=" * 60)
    
    for size in sizes:
        for num_workers in worker_counts:
            times = []
            all_stats = []
            
            print(f"\n\nTestando grade {size}x{size} com {num_workers} workers...")
            print(f"Aguardando {num_workers} workers conectarem...")
            
            for run in range(num_runs):
                forest = ForestFireDistributedServer(size, num_workers=num_workers)
                steps, exec_time, stats = forest.simulate()
                times.append(exec_time)
                all_stats.append(stats)
                print(f"  Run {run+1}/{num_runs}: {exec_time:.4f}s - {stats['steps']} passos - {stats['burn_percentage']:.1f}% queimado")
            
            avg_time = np.mean(times)
            std_time = np.std(times)
            avg_steps = np.mean([s['steps'] for s in all_stats])
            avg_burn = np.mean([s['burn_percentage'] for s in all_stats])
            
            result = {
                'size': size,
                'cells': size * size,
                'num_workers': num_workers,
                'avg_time': avg_time,
                'std_time': std_time,
                'avg_steps': avg_steps,
                'avg_burn_percentage': avg_burn,
                'times': times
            }
            results.append(result)
            
            print(f"  Média: {avg_time:.4f}s (±{std_time:.4f}s)")
    
    # Salva resultados
    with open('benchmark_distributed.json', 'w') as f:
        json.dump(results, f, indent=2)
    
    print("\n" + "=" * 60)
    print("Resultados salvos em 'benchmark_distributed.json'")
    print("=" * 60)
    
    return results


if __name__ == "__main__":
    import argparse
    
    parser = argparse.ArgumentParser(description='Simulação Distribuída de Incêndio Florestal')
    parser.add_argument('--worker', action='store_true', help='Executar como worker')
    parser.add_argument('--server', action='store_true', help='Executar como servidor')
    parser.add_argument('--benchmark', action='store_true', help='Executar benchmark')
    parser.add_argument('--host', type=str, default='localhost', help='Endereço do servidor')
    parser.add_argument('--port', type=int, default=5000, help='Porta (default: 5000)')
    parser.add_argument('--size', type=int, default=100, help='Tamanho da grade (default: 100)')
    parser.add_argument('--workers', type=int, default=2, help='Número de workers (default: 2)')
    parser.add_argument('--sizes', type=int, nargs='+', default=[100, 200, 300], 
                        help='Tamanhos para benchmark')
    parser.add_argument('--worker-counts', type=int, nargs='+', default=[2, 4], 
                        help='Números de workers para benchmark')
    
    args = parser.parse_args()
    
    if args.worker:
        # Modo worker
        print("Iniciando worker...")
        worker = ForestFireDistributedWorker(args.host, args.port)
        worker.connect_and_work()
        
    elif args.benchmark:
        # Modo benchmark
        print("\nIMPORTANTE: Antes de continuar, inicie os workers em outras janelas/máquinas!")
        print(f"Exemplo: python forest_fire_distributed.py --worker --host {args.host} --port {args.port}")
        input("\nPressione ENTER quando os workers estiverem prontos...")
        run_benchmark_distributed(args.sizes, args.worker_counts)
        
    elif args.server:
        # Modo servidor simples
        print("Executando simulação distribuída (servidor)...")
        print(f"\nIMPORTANTE: Inicie {args.workers} workers antes de continuar!")
        print(f"Exemplo: python forest_fire_distributed.py --worker --host {args.host} --port {args.port}")
        input("\nPressione ENTER quando os workers estiverem prontos...")
        
        forest = ForestFireDistributedServer(args.size, num_workers=args.workers, port=args.port)
        steps, exec_time, stats = forest.simulate()
        
        print(f"\nResultados:")
        print(f"  Tamanho da grade: {args.size}x{args.size}")
        print(f"  Número de workers: {args.workers}")
        print(f"  Tempo de execução: {exec_time:.4f}s")
        print(f"  Passos: {steps}")
        print(f"  Árvores iniciais: {stats['initial_trees']}")
        print(f"  Árvores finais: {stats['final_trees']}")
        print(f"  Árvores queimadas: {stats['burned_trees']}")
        print(f"  Porcentagem queimada: {stats['burn_percentage']:.2f}%")
    
    else:
        parser.print_help()
        print("\n\nExemplos de uso:")
        print("  Worker:  python forest_fire_distributed.py --worker")
        print("  Servidor: python forest_fire_distributed.py --server --size 200 --workers 2")
        print("  Benchmark: python forest_fire_distributed.py --benchmark")
