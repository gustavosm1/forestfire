"""
Simulação Paralela de Incêndio Florestal usando Threads
Baseado no modelo de autômato celular para propagação de fogo

Referências:
- Drossel, B., & Schwabl, F. (1992). "Self-organized critical forest-fire model"
- Physical Review Letters, 69(11), 1629.
"""

import numpy as np
import time
from typing import Tuple
import threading
import json
from queue import Queue

class ForestFireParallel:
    """
    Modelo de incêndio florestal paralelo usando threads.
    A grade é dividida em regiões processadas por threads diferentes.
    
    Estados:
    0 = Vazio (queimado)
    1 = Árvore
    2 = Fogo
    """
    
    def __init__(self, size: int, num_threads: int = 4, tree_prob: float = 0.6, fire_prob: float = 0.001):
        """
        Inicializa a simulação paralela.
        
        Args:
            size: Tamanho da grade (size x size)
            num_threads: Número de threads a utilizar para paralelização
            tree_prob: Probabilidade inicial de uma célula ter árvore (60%)
            fire_prob: Probabilidade de ignição espontânea (0.1%)
        """
        self.size = size
        self.num_threads = num_threads
        self.tree_prob = tree_prob
        self.fire_prob = fire_prob
        # Grade compartilhada entre threads (matriz NumPy)
        self.grid = np.zeros((size, size), dtype=np.int8)
        # Lock para proteção de seções críticas (se necessário)
        self.lock = threading.Lock()
        # Barreira para sincronização de threads ao final de cada passo
        self.barrier = threading.Barrier(num_threads)
        self.initialize_forest()
        
    def initialize_forest(self):
        """Inicializa a floresta com árvores aleatórias."""
        self.grid = (np.random.random((self.size, self.size)) < self.tree_prob).astype(np.int8)
        
        # Inicia alguns focos de incêndio
        num_fires = max(1, self.size // 50)
        for _ in range(num_fires):
            x = np.random.randint(0, self.size)
            y = np.random.randint(0, self.size)
            self.grid[x, y] = 2
    
    def get_neighbors(self, x: int, y: int) -> list:
        """Retorna os vizinhos válidos de uma célula (Von Neumann)."""
        neighbors = []
        for dx, dy in [(-1, 0), (1, 0), (0, -1), (0, 1)]:
            nx, ny = x + dx, y + dy
            if 0 <= nx < self.size and 0 <= ny < self.size:
                neighbors.append((nx, ny))
        return neighbors
    
    def process_region(self, start_row: int, end_row: int, new_grid: np.ndarray, fire_detected: list):
        """
        Processa uma região da grade (linhas start_row até end_row).
        Cada thread executa esta função em paralelo para sua região atribuída.
        
        Estratégia de Paralelização:
        - Divisão horizontal: cada thread processa um bloco de linhas
        - Exemplo com 4 threads em grade 200x200:
          Thread 0: linhas 0-49
          Thread 1: linhas 50-99
          Thread 2: linhas 100-149
          Thread 3: linhas 150-199
        
        Args:
            start_row: Linha inicial desta região (inclusive)
            end_row: Linha final desta região (exclusive)
            new_grid: Nova grade para escrever resultados (compartilhada)
            fire_detected: Lista compartilhada para indicar se há fogo
        """
        local_fire = False  # Flag local para detectar fogo nesta região
        
        # OTIMIZAÇÃO: Cache local de variáveis para acesso mais rápido
        # Evita acessar self.grid e self.size repetidamente
        grid = self.grid  # Referência local à grade (mais rápido que self.grid)
        size = self.size
        fire_prob = self.fire_prob
        
        # Processa apenas as linhas atribuídas a esta thread
        for x in range(start_row, end_row):
            for y in range(size):
                cell = grid[x, y]  # Lê estado atual da célula
                
                # REGRA 1: Fogo se apaga
                if cell == 2:  # Fogo
                    new_grid[x, y] = 0  # Vira vazio
                    local_fire = True
                    
                    # REGRA 2: Propaga fogo (otimizado inline sem chamada de função)
                    # Verificação de bordas embutida para performance
                    if x > 0 and grid[x-1, y] == 1:  # Vizinho acima
                        new_grid[x-1, y] = 2
                    if x < size-1 and grid[x+1, y] == 1:  # Vizinho abaixo
                        new_grid[x+1, y] = 2
                    if y > 0 and grid[x, y-1] == 1:  # Vizinho à esquerda
                        new_grid[x, y-1] = 2
                    if y < size-1 and grid[x, y+1] == 1:  # Vizinho à direita
                        new_grid[x, y+1] = 2
                            
                # REGRA 3: Ignição espontânea
                elif cell == 1:  # Árvore
                    if np.random.random() < fire_prob:
                        new_grid[x, y] = 2
                        local_fire = True
        
        # Atualiza flag compartilhada se detectou fogo nesta região
        # Lista é mutável, então pode ser compartilhada entre threads
        if local_fire:
            fire_detected[0] = True
    
    def step_parallel(self) -> bool:
        """
        Executa um passo da simulação usando paralelização com threads.
        
        Algoritmo:
        1. Divide grade em regiões (uma por thread)
        2. Cria threads para processar cada região em paralelo
        3. Aguarda todas as threads terminarem (join)
        4. Consolida resultados
        
        IMPORTANTE: Todas as threads devem terminar antes de atualizar a grade,
        garantindo que todas leem o mesmo estado e escrevem simultaneamente.
        
        Returns:
            True se ainda há fogo, False caso contrário
        """
        # Cria nova grade para escrever resultados (evita race conditions)
        new_grid = self.grid.copy()
        
        # Lista compartilhada entre threads para detectar se há fogo
        # Usamos lista (mutável) ao invés de variável simples
        fire_detected = [False]
        
        # DIVISÃO DE TRABALHO: calcula quantas linhas cada thread processa
        rows_per_thread = self.size // self.num_threads
        threads = []
        
        # Cria e inicia todas as threads
        for i in range(self.num_threads):
            # Calcula região desta thread
            start_row = i * rows_per_thread
            if i == self.num_threads - 1:
                # Última thread pega linhas restantes (se divisão não for exata)
                end_row = self.size
            else:
                end_row = (i + 1) * rows_per_thread
            
            # Cria thread passando sua região
            thread = threading.Thread(
                target=self.process_region,
                args=(start_row, end_row, new_grid, fire_detected)
            )
            threads.append(thread)
            thread.start()  # Inicia processamento paralelo
        
        # SINCRONIZAÇÃO: Aguarda todas as threads terminarem
        # Necessário para garantir que toda a grade foi processada
        for thread in threads:
            thread.join()  # Bloqueia até thread terminar
        
        # Atualiza grade com resultados consolidados
        self.grid = new_grid
        return fire_detected[0]  # Retorna se alguma thread detectou fogo
    
    def simulate(self, max_steps: int = 1000) -> Tuple[int, float, dict]:
        """
        Executa a simulação completa.
        
        Args:
            max_steps: Número máximo de iterações
            
        Returns:
            Tupla com (número de passos, tempo de execução, estatísticas)
        """
        start_time = time.time()
        steps = 0
        
        initial_trees = np.sum(self.grid == 1)
        
        while steps < max_steps:
            has_fire = self.step_parallel()
            steps += 1
            
            if not has_fire:
                break
        
        end_time = time.time()
        execution_time = end_time - start_time
        
        final_trees = np.sum(self.grid == 1)
        burned_trees = initial_trees - final_trees
        burn_percentage = (burned_trees / initial_trees * 100) if initial_trees > 0 else 0
        
        stats = {
            'initial_trees': int(initial_trees),
            'final_trees': int(final_trees),
            'burned_trees': int(burned_trees),
            'burn_percentage': float(burn_percentage),
            'steps': steps,
            'num_threads': self.num_threads
        }
        
        return steps, execution_time, stats
    
    def get_grid_copy(self):
        """Retorna uma cópia da grade atual."""
        return self.grid.copy()


def run_benchmark_threads(sizes: list, thread_counts: list, num_runs: int = 5):
    """
    Executa benchmark para diferentes tamanhos de grade e números de threads.
    
    Args:
        sizes: Lista de tamanhos de grade para testar
        thread_counts: Lista de números de threads para testar
        num_runs: Número de execuções para cada configuração
    """
    results = []
    
    print("=" * 60)
    print("BENCHMARK - VERSÃO PARALELA (THREADS)")
    print("=" * 60)
    
    for size in sizes:
        for num_threads in thread_counts:
            times = []
            all_stats = []
            
            print(f"\nTestando grade {size}x{size} com {num_threads} threads...")
            
            for run in range(num_runs):
                forest = ForestFireParallel(size, num_threads=num_threads)
                steps, exec_time, stats = forest.simulate()
                times.append(exec_time)
                all_stats.append(stats)
                print(f"  Run {run+1}/{num_runs}: {exec_time:.4f}s - {stats['steps']} passos - {stats['burn_percentage']:.1f}% queimado")
            
            avg_time = np.mean(times)
            std_time = np.std(times)
            avg_steps = np.mean([s['steps'] for s in all_stats])
            avg_burn = np.mean([s['burn_percentage'] for s in all_stats])
            
            result = {
                'size': size,
                'cells': size * size,
                'num_threads': num_threads,
                'avg_time': avg_time,
                'std_time': std_time,
                'avg_steps': avg_steps,
                'avg_burn_percentage': avg_burn,
                'times': times
            }
            results.append(result)
            
            print(f"  Média: {avg_time:.4f}s (±{std_time:.4f}s)")
            print(f"  Passos médios: {avg_steps:.1f}")
            print(f"  Queimado médio: {avg_burn:.1f}%")
    
    # Salva resultados
    with open('benchmark_parallel.json', 'w') as f:
        json.dump(results, f, indent=2)
    
    print("\n" + "=" * 60)
    print("Resultados salvos em 'benchmark_parallel.json'")
    print("=" * 60)
    
    return results


def compare_with_sequential(size: int = 200, num_runs: int = 5):
    """
    Compara o desempenho da versão paralela com a sequencial.
    
    Args:
        size: Tamanho da grade
        num_runs: Número de execuções para cada configuração
    """
    from forest_fire_sequential import ForestFireSequential
    
    print("=" * 60)
    print("COMPARAÇÃO: SEQUENCIAL vs PARALELA")
    print("=" * 60)
    print(f"\nTamanho da grade: {size}x{size}")
    
    # Versão sequencial
    print("\nExecutando versão SEQUENCIAL...")
    seq_times = []
    for run in range(num_runs):
        forest = ForestFireSequential(size)
        steps, exec_time, stats = forest.simulate()
        seq_times.append(exec_time)
        print(f"  Run {run+1}/{num_runs}: {exec_time:.4f}s")
    
    seq_avg = np.mean(seq_times)
    print(f"Média sequencial: {seq_avg:.4f}s")
    
    # Versões paralelas
    thread_counts = [2, 4, 8, 16]
    for num_threads in thread_counts:
        print(f"\nExecutando versão PARALELA com {num_threads} threads...")
        par_times = []
        for run in range(num_runs):
            forest = ForestFireParallel(size, num_threads=num_threads)
            steps, exec_time, stats = forest.simulate()
            par_times.append(exec_time)
            print(f"  Run {run+1}/{num_runs}: {exec_time:.4f}s")
        
        par_avg = np.mean(par_times)
        speedup = seq_avg / par_avg
        efficiency = speedup / num_threads * 100
        
        print(f"Média paralela: {par_avg:.4f}s")
        print(f"Speedup: {speedup:.2f}x")
        print(f"Eficiência: {efficiency:.1f}%")


if __name__ == "__main__":
    import argparse
    
    parser = argparse.ArgumentParser(description='Simulação Paralela de Incêndio Florestal')
    parser.add_argument('--benchmark', action='store_true', help='Executar benchmark')
    parser.add_argument('--compare', action='store_true', help='Comparar com versão sequencial')
    parser.add_argument('--size', type=int, default=100, help='Tamanho da grade (default: 100)')
    parser.add_argument('--threads', type=int, default=4, help='Número de threads (default: 4)')
    parser.add_argument('--sizes', type=int, nargs='+', default=[50, 100, 200, 300, 400], 
                        help='Tamanhos para benchmark (default: 50 100 200 300 400)')
    parser.add_argument('--thread-counts', type=int, nargs='+', default=[2, 4, 8, 16], 
                        help='Números de threads para benchmark (default: 2 4 8 16)')
    
    args = parser.parse_args()
    
    if args.benchmark:
        run_benchmark_threads(args.sizes, args.thread_counts)
    elif args.compare:
        compare_with_sequential(args.size)
    else:
        # Execução simples
        print("Executando simulação paralela...")
        forest = ForestFireParallel(args.size, num_threads=args.threads)
        steps, exec_time, stats = forest.simulate()
        
        print(f"\nResultados:")
        print(f"  Tamanho da grade: {args.size}x{args.size}")
        print(f"  Número de threads: {args.threads}")
        print(f"  Tempo de execução: {exec_time:.4f}s")
        print(f"  Passos: {steps}")
        print(f"  Árvores iniciais: {stats['initial_trees']}")
        print(f"  Árvores finais: {stats['final_trees']}")
        print(f"  Árvores queimadas: {stats['burned_trees']}")
        print(f"  Porcentagem queimada: {stats['burn_percentage']:.2f}%")
