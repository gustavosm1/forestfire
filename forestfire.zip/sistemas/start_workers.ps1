# Script auxiliar para executar workers distribuídos em múltiplas janelas
# Windows PowerShell

param(
    [int]$NumWorkers = 2,
    [string]$Host = "localhost",
    [int]$Port = 5000
)

Write-Host "=" -NoNewline -ForegroundColor Cyan
Write-Host ("=" * 59) -ForegroundColor Cyan
Write-Host "INICIANDO WORKERS DISTRIBUÍDOS" -ForegroundColor Yellow
Write-Host "=" -NoNewline -ForegroundColor Cyan
Write-Host ("=" * 59) -ForegroundColor Cyan
Write-Host ""
Write-Host "Número de workers: $NumWorkers" -ForegroundColor Green
Write-Host "Servidor: ${Host}:${Port}" -ForegroundColor Green
Write-Host ""

# Array para armazenar processos
$processes = @()

# Inicia cada worker em uma nova janela
for ($i = 1; $i -le $NumWorkers; $i++) {
    Write-Host "Iniciando Worker $i..." -ForegroundColor Cyan
    
    $process = Start-Process powershell -ArgumentList @(
        "-NoExit",
        "-Command",
        "python forest_fire_distributed.py --worker --host $Host --port $Port"
    ) -PassThru
    
    $processes += $process
    Start-Sleep -Milliseconds 500
}

Write-Host ""
Write-Host "✓ Todos os workers foram iniciados!" -ForegroundColor Green
Write-Host ""
Write-Host "Agora execute o servidor em outra janela:" -ForegroundColor Yellow
Write-Host "  python forest_fire_distributed.py --server --workers $NumWorkers --port $Port" -ForegroundColor White
Write-Host ""
Write-Host "Pressione qualquer tecla para encerrar todos os workers..." -ForegroundColor Red
$null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")

# Encerra todos os workers
Write-Host ""
Write-Host "Encerrando workers..." -ForegroundColor Yellow

foreach ($process in $processes) {
    if (!$process.HasExited) {
        Stop-Process -Id $process.Id -Force
    }
}

Write-Host "✓ Todos os workers foram encerrados" -ForegroundColor Green
