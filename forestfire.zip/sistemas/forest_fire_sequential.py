"""
Simulação Sequencial de Incêndio Florestal
Baseado no modelo de autômato celular para propagação de fogo

Referências:
- Drossel, B., & Schwabl, F. (1992). "Self-organized critical forest-fire model"
- Physical Review Letters, 69(11), 1629.
"""

import numpy as np
import time
from typing import Tuple
import matplotlib.pyplot as plt
from matplotlib.animation import FuncAnimation
import json

class ForestFireSequential:
    """
    Modelo de incêndio florestal usando autômato celular.
    
    Estados:
    0 = Vazio (queimado)
    1 = Árvore
    2 = Fogo
    """
    
    def __init__(self, size: int, tree_prob: float = 0.6, fire_prob: float = 0.001):
        """
        Inicializa a simulação.
        
        Args:
            size: Tamanho da grade (size x size)
            tree_prob: Probabilidade inicial de uma célula ter árvore
            fire_prob: Probabilidade de ignição espontânea
        """
        self.size = size
        self.tree_prob = tree_prob
        self.fire_prob = fire_prob
        self.grid = np.zeros((size, size), dtype=np.int8)
        self.initialize_forest()
        
    def initialize_forest(self):
        """Inicializa a floresta com árvores aleatórias."""
        # Cria matriz aleatória e compara com probabilidade de árvore
        # Valores < tree_prob (0.6) se tornam árvores (True -> 1)
        # Valores >= tree_prob se tornam vazios (False -> 0)
        self.grid = (np.random.random((self.size, self.size)) < self.tree_prob).astype(np.int8)
        
        # Inicia focos de incêndio aleatórios na grade
        # Quantidade proporcional ao tamanho: 1 foco a cada 50 células de lado
        num_fires = max(1, self.size // 50)
        for _ in range(num_fires):
            # Escolhe posição aleatória para iniciar fogo
            x = np.random.randint(0, self.size)
            y = np.random.randint(0, self.size)
            self.grid[x, y] = 2  # Estado 2 = FOGO
    
    def get_neighbors(self, x: int, y: int) -> list:
        """Retorna os vizinhos válidos de uma célula (Von Neumann).
        
        Vizinhança de Von Neumann: apenas 4 vizinhos ortogonais (cima, baixo, esquerda, direita)
        Não inclui diagonais (diferente da vizinhança de Moore)
        """
        neighbors = []
        # Direções: cima, baixo, esquerda, direita
        for dx, dy in [(-1, 0), (1, 0), (0, -1), (0, 1)]:
            nx, ny = x + dx, y + dy
            # Verifica se vizinho está dentro dos limites da grade
            if 0 <= nx < self.size and 0 <= ny < self.size:
                neighbors.append((nx, ny))
        return neighbors
    
    def step(self) -> bool:
        """
        Executa um passo da simulação (1 iteração do autômato celular).
        
        Regras do modelo Forest Fire:
        1. Fogo -> Vazio (célula queimada apaga e fica vazia)
        2. Árvore com vizinho em fogo -> Fogo (propagação)
        3. Árvore -> Fogo com probabilidade fire_prob (ignição aleatória)
        
        Returns:
            True se ainda há fogo na grade, False caso contrário (simulação termina)
        """
        # Cria cópia da grade para não modificar durante a leitura
        # Importante: todas as células devem ser atualizadas simultaneamente
        new_grid = self.grid.copy()
        has_fire = False  # Flag para verificar se simulação deve continuar
        
        # Percorre todas as células da grade (processamento sequencial)
        for x in range(self.size):
            for y in range(self.size):
                # REGRA 1: Células em fogo se apagam
                if self.grid[x, y] == 2:  # Fogo
                    new_grid[x, y] = 0  # Vira vazio (queimado)
                    has_fire = True  # Ainda há fogo ativo neste passo
                    
                    # REGRA 2: Propaga fogo para árvores vizinhas
                    for nx, ny in self.get_neighbors(x, y):
                        if self.grid[nx, ny] == 1:  # Se vizinho é árvore
                            new_grid[nx, ny] = 2  # Vizinho pega fogo
                            
                # REGRA 3: Ignição espontânea (modelagem de raios, etc)
                elif self.grid[x, y] == 1:  # Árvore saudável
                    # Chance pequena (0.1%) de pegar fogo espontaneamente
                    if np.random.random() < self.fire_prob:
                        new_grid[x, y] = 2  # Árvore pega fogo
                        has_fire = True
        
        # Atualiza grade com novo estado
        self.grid = new_grid
        return has_fire  # Retorna se há fogo (continua) ou não (para)
    
    def simulate(self, max_steps: int = 1000) -> Tuple[int, float, dict]:
        """
        Executa a simulação completa.
        
        Args:
            max_steps: Número máximo de iterações
            
        Returns:
            Tupla com (número de passos, tempo de execução, estatísticas)
        """
        start_time = time.time()
        steps = 0
        
        initial_trees = np.sum(self.grid == 1)
        
        while steps < max_steps:
            has_fire = self.step()
            steps += 1
            
            if not has_fire:
                break
        
        end_time = time.time()
        execution_time = end_time - start_time
        
        final_trees = np.sum(self.grid == 1)
        burned_trees = initial_trees - final_trees
        burn_percentage = (burned_trees / initial_trees * 100) if initial_trees > 0 else 0
        
        stats = {
            'initial_trees': int(initial_trees),
            'final_trees': int(final_trees),
            'burned_trees': int(burned_trees),
            'burn_percentage': float(burn_percentage),
            'steps': steps
        }
        
        return steps, execution_time, stats
    
    def get_grid_copy(self):
        """Retorna uma cópia da grade atual."""
        return self.grid.copy()


def run_benchmark(sizes: list, num_runs: int = 5):
    """
    Executa benchmark para diferentes tamanhos de grade.
    
    Args:
        sizes: Lista de tamanhos de grade para testar
        num_runs: Número de execuções para cada tamanho
    """
    results = []
    
    print("=" * 60)
    print("BENCHMARK - VERSÃO SEQUENCIAL")
    print("=" * 60)
    
    for size in sizes:
        times = []
        all_stats = []
        
        print(f"\nTestando grade {size}x{size}...")
        
        for run in range(num_runs):
            forest = ForestFireSequential(size)
            steps, exec_time, stats = forest.simulate()
            times.append(exec_time)
            all_stats.append(stats)
            print(f"  Run {run+1}/{num_runs}: {exec_time:.4f}s - {stats['steps']} passos - {stats['burn_percentage']:.1f}% queimado")
        
        avg_time = np.mean(times)
        std_time = np.std(times)
        avg_steps = np.mean([s['steps'] for s in all_stats])
        avg_burn = np.mean([s['burn_percentage'] for s in all_stats])
        
        result = {
            'size': size,
            'cells': size * size,
            'avg_time': avg_time,
            'std_time': std_time,
            'avg_steps': avg_steps,
            'avg_burn_percentage': avg_burn,
            'times': times
        }
        results.append(result)
        
        print(f"  Média: {avg_time:.4f}s (±{std_time:.4f}s)")
        print(f"  Passos médios: {avg_steps:.1f}")
        print(f"  Queimado médio: {avg_burn:.1f}%")
    
    # Salva resultados
    with open('benchmark_sequential.json', 'w') as f:
        json.dump(results, f, indent=2)
    
    print("\n" + "=" * 60)
    print("Resultados salvos em 'benchmark_sequential.json'")
    print("=" * 60)
    
    return results


def visualize_simulation(size: int = 100, save_animation: bool = False):
    """
    Visualiza a simulação em tempo real.
    
    Args:
        size: Tamanho da grade
        save_animation: Se True, salva a animação como GIF
    """
    forest = ForestFireSequential(size)
    
    fig, ax = plt.subplots(figsize=(10, 10))
    
    # Cores: Vazio (preto), Árvore (verde), Fogo (vermelho)
    colors = ['black', 'green', 'red']
    cmap = plt.matplotlib.colors.ListedColormap(colors)
    
    im = ax.imshow(forest.grid, cmap=cmap, vmin=0, vmax=2)
    ax.set_title('Simulação de Incêndio Florestal - Passo 0')
    ax.axis('off')
    
    step_counter = [0]
    
    def update(frame):
        has_fire = forest.step()
        step_counter[0] += 1
        
        im.set_array(forest.grid)
        ax.set_title(f'Simulação de Incêndio Florestal - Passo {step_counter[0]}')
        
        if not has_fire:
            ani.event_source.stop()
        
        return [im]
    
    ani = FuncAnimation(fig, update, interval=100, blit=True)
    
    if save_animation:
        ani.save('forest_fire_sequential.gif', writer='pillow', fps=10)
        print("Animação salva como 'forest_fire_sequential.gif'")
    
    plt.show()


if __name__ == "__main__":
    import argparse
    
    parser = argparse.ArgumentParser(description='Simulação Sequencial de Incêndio Florestal')
    parser.add_argument('--benchmark', action='store_true', help='Executar benchmark')
    parser.add_argument('--visualize', action='store_true', help='Visualizar simulação')
    parser.add_argument('--size', type=int, default=100, help='Tamanho da grade (default: 100)')
    parser.add_argument('--sizes', type=int, nargs='+', default=[50, 100, 200, 300, 400], 
                        help='Tamanhos para benchmark (default: 50 100 200 300 400)')
    
    args = parser.parse_args()
    
    if args.benchmark:
        run_benchmark(args.sizes)
    elif args.visualize:
        visualize_simulation(args.size)
    else:
        # Execução simples
        print("Executando simulação sequencial...")
        forest = ForestFireSequential(args.size)
        steps, exec_time, stats = forest.simulate()
        
        print(f"\nResultados:")
        print(f"  Tamanho da grade: {args.size}x{args.size}")
        print(f"  Tempo de execução: {exec_time:.4f}s")
        print(f"  Passos: {steps}")
        print(f"  Árvores iniciais: {stats['initial_trees']}")
        print(f"  Árvores finais: {stats['final_trees']}")
        print(f"  Árvores queimadas: {stats['burned_trees']}")
        print(f"  Porcentagem queimada: {stats['burn_percentage']:.2f}%")
